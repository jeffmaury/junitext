package net.sourceforge.retroweaver.runtime.java.lang;

public class Double_ {

	private Double_() {
		// private constructor
	}

	public static Double valueOf(final double val) {
		return new Double(val);
	}

}
