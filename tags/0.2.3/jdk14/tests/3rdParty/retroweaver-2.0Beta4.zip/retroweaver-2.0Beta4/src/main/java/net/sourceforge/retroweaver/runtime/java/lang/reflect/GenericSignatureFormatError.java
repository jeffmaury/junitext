package net.sourceforge.retroweaver.runtime.java.lang.reflect;

public class GenericSignatureFormatError extends ClassFormatError {

	public GenericSignatureFormatError() {
		super();
	}

}
