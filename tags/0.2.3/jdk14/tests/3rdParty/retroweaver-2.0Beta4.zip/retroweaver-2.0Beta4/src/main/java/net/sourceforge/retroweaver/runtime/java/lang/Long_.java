package net.sourceforge.retroweaver.runtime.java.lang;

public class Long_ {

	private Long_() {
		// private constructor
	}

	public static Long valueOf(final long val) {
		return new Long(val);
	}

}
