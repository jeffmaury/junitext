package net.sourceforge.retroweaver.runtime.java.lang.reflect;

public interface Type {

}
