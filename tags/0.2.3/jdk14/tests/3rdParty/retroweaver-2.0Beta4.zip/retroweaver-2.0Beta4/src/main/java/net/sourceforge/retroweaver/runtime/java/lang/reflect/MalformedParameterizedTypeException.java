package net.sourceforge.retroweaver.runtime.java.lang.reflect;

public class MalformedParameterizedTypeException extends RuntimeException {

	public MalformedParameterizedTypeException() {
		super();
	}

}
