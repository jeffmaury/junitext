package net.sourceforge.retroweaver.runtime.java.util;

public class IllegalFormatException extends IllegalArgumentException {

}
