package net.sourceforge.retroweaver.runtime.java.math;

import java.math.BigInteger;

public class BigInteger_ {

	public static final BigInteger TEN = BigInteger.valueOf(10);

}

