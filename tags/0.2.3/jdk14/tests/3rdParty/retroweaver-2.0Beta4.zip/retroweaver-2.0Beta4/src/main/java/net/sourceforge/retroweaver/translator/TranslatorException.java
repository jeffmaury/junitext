package net.sourceforge.retroweaver.translator;

import net.sourceforge.retroweaver.RetroWeaverException;

public class TranslatorException extends RetroWeaverException {

	public TranslatorException(String msg) {
		super(msg);
	}

}
