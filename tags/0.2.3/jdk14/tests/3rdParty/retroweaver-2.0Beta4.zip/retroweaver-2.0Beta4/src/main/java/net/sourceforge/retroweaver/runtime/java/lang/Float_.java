package net.sourceforge.retroweaver.runtime.java.lang;

public class Float_ {

	private Float_() {
		// private constructor
	}

	public static Float valueOf(final float val) {
		return new Float(val);
	}

}
