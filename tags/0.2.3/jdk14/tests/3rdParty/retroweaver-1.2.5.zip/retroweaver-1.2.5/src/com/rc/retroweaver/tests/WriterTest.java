package com.rc.retroweaver.tests;

import java.io.IOException;
import java.io.Writer;

public class WriterTest extends AbstractTest {

	public void testWriter() {
		class MyWriter extends Writer {
			public void close() {}
			public void flush() {}
			public void write(char cbuf[], int off, int len) throws IOException {}

			public Writer append(CharSequence csq) throws IOException {return null;};
			public Writer append(CharSequence csq, int start, int end) throws IOException {return null;};
			public Writer append(char c) throws IOException {return null;};
		}

		try {
			MyWriter w = new MyWriter();
			w.write(' ');

			success("testWriter");
		} catch (IOException ioe) {
		}
	}

}
